package com.wf.np.bootappsecure.dto;


import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Length;

public class SearchEmployeeInputDto {

	
	/*
	 * @NotBlank(message="Employee ID is required")
	 * 
	 * @Length(min=1, max=7, message="Cannot exceed 7 characters") private String
	 * lanID;
	 */
	
	@NotNull(message="Employee ID is required") 
	private Long empID;
	
	/*
	 * @NotBlank(message="First Name is required")
	 * 
	 * @Length(min=1, max=15, message="Cannot exceed 15 characters")
	 */
	private String firstName;
	
	/*
	 * @NotBlank(message="Last Name is required")
	 * 
	 * @Length(min=1, max=15, message="Cannot exceed 15 characters")
	 */
	private String lastName;

	public Long getEmpID() {
		return empID;
	}

	public void setEmpID(Long empID) {
		this.empID = empID;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
	
	/*
	 * @NotNull(message="Account Number is required") private Long acctNum; private
	 * String startDate; private String endDate;
	 * 
	 * 
	 * public Long getAcctNum() { return acctNum; } public void setAcctNum(Long
	 * acctNum) { this.acctNum = acctNum; } public String getStartDate() { return
	 * startDate; } public void setStartDate(String startDate) { this.startDate =
	 * startDate; } public String getEndDate() { return endDate; } public void
	 * setEndDate(String endDate) { this.endDate = endDate; }
	 */
	
}
