package com.wf.np.bootappsecure.controller;

import java.io.File;
import java.text.ParseException;
import java.util.List;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.wf.np.bootappsecure.dto.*;
import com.wf.np.bootappsecure.exception.EmployeeNotFoundException;
import com.wf.np.bootappsecure.service.*;

@RequestMapping("/employee")
@Controller
public class EmployeeController {

	// add dependency
	@Autowired
	private EmployeeService employeeService;
	
	
	@RequestMapping(value="/nplogin", method=RequestMethod.GET)
	public String npLogin(Model model) {
		EmployeeInputDto empInputDto = new EmployeeInputDto();
		model.addAttribute("npLogin", empInputDto);
		return "np-login";
	}
	
		
	@RequestMapping(value="/nplogin", method=RequestMethod.POST)
	public String npLoginValidate(@Valid @ModelAttribute("npLogin") EmployeeInputDto empInputDto, 
									BindingResult result,
									Model model) {
		if (result.hasErrors()) 
			return "np-login";
		
		EmployeeOutputDto empOutputDto = this.employeeService.fetchSingleEmployee(empInputDto.getEmpID());
		//EmployeeOutputDto empOutputDto = this.employeeService.fetchSingleCustomer(empInputDto.getLan());
		
		if(empInputDto.getPassword().equals(empOutputDto.getSysPassword())) 
			return "np-home";
		
		return "loginerror";
	}
	
	@RequestMapping(value="/home", method=RequestMethod.GET)
	public String npHome(Model model) {
		NPHome npHome = new NPHome();
		model.addAttribute("npHome", npHome);
		//model.addAttribute("ibsHome", npHome);
		return "np-home";			
	}
	
	@RequestMapping(value="/search", method=RequestMethod.GET) 
	public String search(Model model) { 
		SearchEmployeeInputDto searchInputDto = new SearchEmployeeInputDto();
		model.addAttribute("searchEmployee", searchInputDto);
		return "search-employee"; 
		}
	
	@RequestMapping(value="/search", method=RequestMethod.POST)
	public String searchConfirm(@Valid @ModelAttribute("searchEmployee") SearchEmployeeInputDto searchInputDto, 
										BindingResult result,
										Model model) throws Exception {
		
		if (result.hasErrors()) {
			return "search-employee";
		}
		
		 EmployeeOutputDto empOutputDto =
		  this.employeeService.fetchSingleEmployee(searchInputDto.getEmpID());
		  	if(empOutputDto == null) { 
				  // throw custom exception 
				  throw new EmployeeNotFoundException("Employee not found with Id : " +
			  searchInputDto.getEmpID()); }
		  
		 model.addAttribute("searchEmployee", empOutputDto);
		 
		EmployeeOutputDto empOutputDtoSpeech = this.employeeService.fetchEmployeePronunciation(searchInputDto.getEmpID());	
		return "search-confirm";
		
	}
	
	@RequestMapping(value="/my-profile", method=RequestMethod.GET) 
	public String myProfile(Model model) { 
		SearchEmployeeInputDto searchInputDto = new SearchEmployeeInputDto();
		model.addAttribute("myProfile", searchInputDto);
		return "my-profile"; 
	}
	
	@RequestMapping(value="/my-profile", method=RequestMethod.POST)
	public String myProfileConfirm(@Valid @ModelAttribute("myProfile") SearchEmployeeInputDto searchInputDto, 
										BindingResult result,
										Model model) throws Exception {
		
		if (result.hasErrors()) {
			return "my-profile";
		}
		
		EmployeeOutputDto empOutputDto = this.employeeService.fetchSingleEmployee(searchInputDto.getEmpID());
		  	if(empOutputDto == null) 
		  		{ 
				  // throw custom exception 
				  throw new EmployeeNotFoundException("Employee not found with Id : " + searchInputDto.getEmpID()); 
				}
		  
		EmployeeOutputDto empOutputDtoCustom = this.employeeService.recordCustomPronunciation(empOutputDto);
		
		model.addAttribute("myProfile", empOutputDtoCustom);
		return "myprofile-edit";
		
	}
	
	@RequestMapping(value="/replay-custom") 
	public String replayCustom(@ModelAttribute("myProfile") EmployeeOutputDto empOutputDtoCustom, Model model) {
		EmployeeOutputDto empOutputDto = this.employeeService.fetchSingleEmployee(empOutputDtoCustom.getEmpID());
	  	if(empOutputDto == null) 
	  		{ 
			  // throw custom exception 
			  throw new EmployeeNotFoundException("Employee not found with Id : " + empOutputDtoCustom.getEmpID()); 
			}
		//System.out.println("emp id from myprofile"+empOutputDtoCustom.getEmpID());
		EmployeeOutputDto empOutputDtoNew = this.employeeService.replayCustomPronunciation(empOutputDtoCustom);
		model.addAttribute("replayCustom", empOutputDtoNew);
		return "replay-custom"; 
	}
	
	@RequestMapping(value="/update-custom")
	public String confirmCustomPron(@Valid @ModelAttribute("replayCustom") EmployeeOutputDto empOutputDtoNew, 
									BindingResult result, Model model) { 
		EmployeeOutputDto empOutputDtoFinal = this.employeeService.updateCustomPronunciation(empOutputDtoNew);
					
		model.addAttribute("replayCustom", empOutputDtoFinal);
		//EmployeeOutputDto empOutputDtoSpeech = this.employeeService.replayCustomPronunciation(empOutputDtoNew);	
		return "update-custom";
	}
	 
}
