package com.wf.np.bootappsecure.service;

import com.wf.np.bootappsecure.dto.EmployeeOutputDto;

public interface EmployeeService {

	//public AdminKycIdOutputDto saveCustDetails(KycDetailsOutputDto kycUpdatedOutputDto);
	public EmployeeOutputDto fetchSingleEmployee(Long empID);
	//public EmployeeOutputDto updatePwd(Long uci, IBSResetPwdInputDto resetPwdInputDto);
	public EmployeeOutputDto fetchEmployeePronunciation(Long empID) throws Exception;
	public EmployeeOutputDto recordCustomPronunciation(EmployeeOutputDto empOutputDto);
	public EmployeeOutputDto replayCustomPronunciation(EmployeeOutputDto empOutputDto);
	public EmployeeOutputDto updateCustomPronunciation(EmployeeOutputDto empOutputDto);
	//public EmployeeOutputDto fetchUpdatedPronunciation(Long empID) throws Exception;
	
}
