package com.wf.np.bootappsecure.serviceImpl;

import javax.sound.sampled.*;
import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;

import javax.sound.sampled.AudioFileFormat;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.TargetDataLine;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.cloud.texttospeech.v1beta1.AudioConfig;
import com.google.cloud.texttospeech.v1beta1.AudioEncoding;
import com.google.cloud.texttospeech.v1beta1.SsmlVoiceGender;
import com.google.cloud.texttospeech.v1beta1.SynthesisInput;
import com.google.cloud.texttospeech.v1beta1.SynthesizeSpeechResponse;
import com.google.cloud.texttospeech.v1beta1.TextToSpeechClient;
import com.google.cloud.texttospeech.v1beta1.VoiceSelectionParams;
import com.google.protobuf.ByteString;
import com.wf.np.bootappsecure.dto.EmployeeOutputDto;
import com.wf.np.bootappsecure.entity.Employee;
//import com.wf.np.bootappsecure.entity.Kyc;
import com.wf.np.bootappsecure.repository.EmployeeRepository;
import com.wf.np.bootappsecure.service.EmployeeService;

import javazoom.jl.player.Player;

@Service
public class EmployeeServiceImpl implements EmployeeService{

	//injecting a dependency
	@Autowired
	private EmployeeRepository repository;
	
	// utility method
	private EmployeeOutputDto convertEntityToOutputDto(Employee employee) {
		EmployeeOutputDto employeeOutputDto = new EmployeeOutputDto();
		
		employeeOutputDto.setEmpID(employee.getEmpID());
		employeeOutputDto.setSysPassword(employee.getSysPassword());
		employeeOutputDto.setFirstName(employee.getFirstName());
		employeeOutputDto.setLastName(employee.getLastName());
		employeeOutputDto.setLegalName(employee.getLegalName());
		employeeOutputDto.setAudioPath(employee.getAudioPath());
		employeeOutputDto.setCustomFlag(false);
		//hackathon
		//employeeOutputDto.setNewPassword(employee.getNewPassword());
		
		return employeeOutputDto;
	}
	
		
	  private Employee convertEmployeeOutputDtoToEntity(EmployeeOutputDto employeeOutputDto) { 
			Employee emp = new Employee();
			emp.setEmpID(employeeOutputDto.getEmpID());
			emp.setFirstName(employeeOutputDto.getFirstName());
			emp.setLastName(employeeOutputDto.getLastName());
			emp.setLegalName(employeeOutputDto.getLegalName());
			emp.setSysPassword(employeeOutputDto.getSysPassword());
			emp.setAudioPath(employeeOutputDto.getAudioPath());
		  	  
		  return emp; 
		}
	 
	/*
	 * private Employee convertPwdResetInputDtoToEntity(IBSResetPwdInputDto
	 * resetPwdInputDto) { Employee cust = new Employee();
	 * cust.setNewPassword(resetPwdInputDto.getNewPassword());
	 * cust.setSysPassword(resetPwdInputDto.getNewPassword());
	 * 
	 * return cust; }
	 */
	/*private Customer convertKycOutputDtoToEntity(KycDetailsOutputDto kycUpdatedOutputDto) {
		Customer cust = new Customer();
		cust.setKyc(kycUpdatedOutputDto.getKycId());
		cust.setSysPassword(sysPassword);
		
		return cust;
	}*/
	
	/*
	 * private AdminKycIdOutputDto convertEntityToAdminOutput(Employee newCust) {
	 * 
	 * AdminKycIdOutputDto adminOutputDto = new AdminKycIdOutputDto();
	 * adminOutputDto.setKycId(newCust.getKyc().getKycId());
	 * adminOutputDto.setUci(newCust.getEmpID());
	 * adminOutputDto.setSysPassword(newCust.getSysPassword());
	 * 
	 * return adminOutputDto; }
	 */
	
	
	@Override
	public EmployeeOutputDto fetchSingleEmployee(Long empID) {
		if(this.repository.existsById(empID)) {
			Employee employee = this.repository.findById(empID).orElse(null);
			EmployeeOutputDto employeeOutputDto = this.convertEntityToOutputDto(employee);
			return employeeOutputDto;
		}
		return null;
	}

	
	/*
	 * @Override public EmployeeOutputDto updatePwd(Long uci, IBSResetPwdInputDto
	 * resetPwdInputDto) { if(this.repository.existsById(uci)) { //get kyc id
	 * Employee customer = this.repository.findById(uci).orElse(null); // convert
	 * input dto into entity Employee cust =
	 * this.convertPwdResetInputDtoToEntity(resetPwdInputDto); // assign the id to
	 * employee cust.setEmpID(uci); cust.setKyc(customer.getKyc()); // save into DB,
	 * returns newly added record // save : PK (id) is null or empty:insert or else
	 * update Employee newCust = this.repository.save(cust); // convert entity into
	 * dto EmployeeOutputDto custOutputDto = this.convertEntityToOutputDto(newCust);
	 * return custOutputDto; } return null; }
	 */
	 
	/*
	 * @Override public AdminKycIdOutputDto saveCustDetails(KycDetailsOutputDto
	 * kycUpdatedOutputDto) { //convert kycUpdatedOutputDto to entity Kyc kyc = new
	 * Kyc(); kyc.setKycId(kycUpdatedOutputDto.getKycId());
	 * 
	 * //joining kyc id to customer table Employee cust = new Employee();
	 * cust.setKyc(kyc);
	 * 
	 * String temp=UUID.randomUUID().toString(); String
	 * sysPassword=temp.replace("-", "");
	 * 
	 * cust.setSysPassword(sysPassword);
	 * 
	 * //cust.setUci(kycUpdatedOutputDto.get); //cust.setKycId(kyc.getKycId());
	 * 
	 * //save customer data Employee newCust = this.repository.save(cust);
	 * AdminKycIdOutputDto adminOutputDto =
	 * this.convertEntityToAdminOutput(newCust);
	 * 
	 * return adminOutputDto;
	 * 
	 * 
	 * }
	 */

	@Override
	public EmployeeOutputDto fetchEmployeePronunciation (Long empID) throws Exception {
		if(this.repository.existsById(empID)) {
			Employee employee = this.repository.findById(empID).orElse(null);
			//if custom pronunciation does not exist
			if(employee.isCustomFlag()==false) {
			EmployeeOutputDto employeeOutputDto = this.convertEntityToOutputDto(employee);
			//String textToSpeak = "Hello World! How are you doing today? This is Google Cloud Text-to-Speech Demo!";
	        //String outputAudioFilePath = "C:/Chandana/output.mp3";
	 
			// Instantiates a client
	        try (TextToSpeechClient textToSpeechClient = TextToSpeechClient.create()) {
	             // Set the text input to be synthesized
	            SynthesisInput input = SynthesisInput.newBuilder().setText(employeeOutputDto.getLegalName()).build();
	 
	            // Build the voice request; languageCode = "en_us"
	            VoiceSelectionParams voice = VoiceSelectionParams.newBuilder().setLanguageCode("en-US")
	                    .setSsmlGender(SsmlVoiceGender.FEMALE)
	                    .build();
	 
	            // Select the type of audio file you want returned
	            AudioConfig audioConfig = AudioConfig.newBuilder().setAudioEncoding(AudioEncoding.MP3) // MP3 audio.
	                    .build();
	 
	            // Perform the text-to-speech request
	            SynthesizeSpeechResponse response = textToSpeechClient.synthesizeSpeech(input, voice, audioConfig);
	 
	            // Get the audio contents from the response
	            ByteString audioContents = response.getAudioContent();
	            
	            BufferedInputStream inputStream = new BufferedInputStream(new ByteArrayInputStream(audioContents.toByteArray()));
	            Player player = new Player(inputStream); //player from jplayer
	            player.play();
	            
	            
			  // Write the response to the output file. 
				/*
				 * try (OutputStream out = new FileOutputStream(outputAudioFilePath)) {
				 * out.write(audioContents.toByteArray());
				 * System.out.println("Audio content written to file \"output.mp3\""); }
				 */
				 
	        }
			return employeeOutputDto;
			}
			
			else {
				
				String audioFilePath = employee.getAudioPath();
				audioPlayer player = new audioPlayer();
				//System.out.println("From replayclass "+audioFilePath);
		        player.play(audioFilePath);
		        EmployeeOutputDto empOutputDtoCustom = this.convertEntityToOutputDto(employee);
		        return empOutputDtoCustom;
		        } 
		}
		return null;
	}

	@Override
	public EmployeeOutputDto recordCustomPronunciation(EmployeeOutputDto empOutputDto) {
		
		if(this.repository.existsById(empOutputDto.getEmpID())) {
			final EmployeeServiceImpl recorder = new EmployeeServiceImpl();
			// path of the wav file
			String audioFileName = empOutputDto.getLegalName().replaceAll("\\s+", "");
			String audioPath = "C:/Chandana/"+audioFileName+".wav";
		    File wavFile = new File(audioPath);
			// creates a new thread that waits for a specified
	        // of time before stopping
	        Thread stopper = new Thread(new Runnable() {
	            public void run() {
	                try {
	                    Thread.sleep(RECORD_TIME);
	                } catch (InterruptedException ex) {
	                    ex.printStackTrace();
	                }
	                recorder.finish();
	            }
	        });
	 
	        stopper.start();
	 
	        // start recording
	        //recorder.start();
	        recorder.start(wavFile);
	        
	        Employee employeeToEntity =  this.convertEmployeeOutputDtoToEntity(empOutputDto);
	        //employeeToEntity.setEmpID(empOutputDto.getEmpID());
	        employeeToEntity.setAudioPath(audioPath);
	        Employee empWithTempFile = this.repository.save(employeeToEntity);
	        // convert entity into dto 
		  	EmployeeOutputDto employeeOutputDto = this.convertEntityToOutputDto(empWithTempFile);
		  	return employeeOutputDto;
		}
		
			  	    
		return null;	
	}
	
	// record duration, in milliseconds
    static final long RECORD_TIME = 8000;  // 8 seconds
    
    // path of the wav file
    //File wavFile = new File("C:/Chandana/RecordAudio.wav");
     
    // format of audio file
    AudioFileFormat.Type fileType = AudioFileFormat.Type.WAVE;
 
    // the line from which audio data is captured
    TargetDataLine line;
 
    /**
     * Defines an audio format
     */
    AudioFormat getAudioFormat() {
        float sampleRate = 16000;
        int sampleSizeInBits = 8;
        int channels = 2;
        boolean signed = true;
        boolean bigEndian = true;
        AudioFormat format = new AudioFormat(sampleRate, sampleSizeInBits,
                                             channels, signed, bigEndian);
        return format;
    }
 
    /**
     * Captures the sound and record into a WAV file
     */
    void start(File wavFile) {
        try {
            AudioFormat format = getAudioFormat();
            DataLine.Info info = new DataLine.Info(TargetDataLine.class, format);
 
            // checks if system supports the data line
            if (!AudioSystem.isLineSupported(info)) {
                System.out.println("Line not supported");
                System.exit(0);
            }
            line = (TargetDataLine) AudioSystem.getLine(info);
            line.open(format);
            line.start();   // start capturing
 
            System.out.println("Start capturing...");
 
            AudioInputStream ais = new AudioInputStream(line);
 
            System.out.println("Start recording...");
 
            // start recording
            AudioSystem.write(ais, fileType, wavFile);
 
        } catch (LineUnavailableException ex) {
            ex.printStackTrace();
        } catch (IOException ioe) {
            ioe.printStackTrace();
        }
    }
 
    /**
     * Closes the target data line to finish capturing and recording
     */
    void finish() {
        line.stop();
        line.close();
        System.out.println("Finished");
    }

	@Override
	public EmployeeOutputDto replayCustomPronunciation(EmployeeOutputDto empOutputDto) {
		
		if(this.repository.existsById(empOutputDto.getEmpID())) {
			Employee empEntity = this.repository.findById(empOutputDto.getEmpID()).orElse(null);
			
			String audioFilePath = empEntity.getAudioPath();
			audioPlayer player = new audioPlayer();
			//System.out.println("From replayclass "+audioFilePath);
	        player.play(audioFilePath);
	        EmployeeOutputDto empOutputDtoNew = this.convertEntityToOutputDto(empEntity);
	        return empOutputDtoNew;
	        } 
		
		return null;
	}
	
	public class audioPlayer implements LineListener {
	     
	    /**
	     * this flag indicates whether the playback completes or not.
	     */
	    boolean playCompleted;
	     
	    /**
	     * Play a given audio file.
	     * @param audioFilePath Path of the audio file.
	     */
	    void play(String audioFilePath) {
	    	//System.out.println("From audioplayer class "+audioFilePath);
	        File audioFile = new File(audioFilePath);
	 
	        try {
	            AudioInputStream audioStream = AudioSystem.getAudioInputStream(audioFile);
	 
	            AudioFormat format = audioStream.getFormat();
	 
	            DataLine.Info info = new DataLine.Info(Clip.class, format);
	 
	            Clip audioClip = (Clip) AudioSystem.getLine(info);
	 
	            audioClip.addLineListener(this);
	 
	            audioClip.open(audioStream);
	             
	            audioClip.start();
	             
	            while (!playCompleted) {
	                // wait for the playback completes
	                try {
	                    Thread.sleep(1000);
	                } catch (InterruptedException ex) {
	                    ex.printStackTrace();
	                }
	            }
	             
	            audioClip.close();
	             
	        } catch (UnsupportedAudioFileException ex) {
	            System.out.println("The specified audio file is not supported.");
	            ex.printStackTrace();
	        } catch (LineUnavailableException ex) {
	            System.out.println("Audio line for playing back is unavailable.");
	            ex.printStackTrace();
	        } catch (IOException ex) {
	            System.out.println("Error playing the audio file.");
	            ex.printStackTrace();
	        }
	         
	    }
	     
	    /**
	     * Listens to the START and STOP events of the audio line.
	     */
	    @Override
	    public void update(LineEvent event) {
	        LineEvent.Type type = event.getType();
	         
	        if (type == LineEvent.Type.START) {
	            System.out.println("Playback started.");
	             
	        } else if (type == LineEvent.Type.STOP) {
	            playCompleted = true;
	            System.out.println("Playback completed.");
	        }
	 
	    }
	}

	@Override
	public EmployeeOutputDto updateCustomPronunciation(EmployeeOutputDto empOutputDto) {
		if(this.repository.existsById(empOutputDto.getEmpID())) { 
			// convert input dto into entity 
			Employee employee = this.repository.findById(empOutputDto.getEmpID()).orElse(null);
			employee.setCustomFlag(true);
			/*
			 * Employee emp = this.convertEmployeeOutputDtoToEntity(empOutputDto);
			 * emp.setEmpID(empOutputDto.getEmpID()); emp.setCustomFlag(true);
			 */
										
				Employee newEmp = this.repository.save(employee); 
				// convert entity into dto 
				EmployeeOutputDto empOutputDtoCustom = this.convertEntityToOutputDto(newEmp);
				return empOutputDtoCustom; 
				
		      } 
		
		return null;
	}


}
