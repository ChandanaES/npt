package com.wf.np.bootappsecure.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.wf.np.bootappsecure.service.EmployeeService;

@RequestMapping("/admin")
@Controller
public class AdminController {
	
	// add dependency
		@Autowired
		private EmployeeService employeeService;
	
	 @RequestMapping("/home") 
	 public String adminHome() {
		 return "admin-home"; 
		 }
	 
	}

