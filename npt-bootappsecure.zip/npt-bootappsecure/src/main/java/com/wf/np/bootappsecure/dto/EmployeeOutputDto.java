package com.wf.np.bootappsecure.dto;

public class EmployeeOutputDto {

	private Long empID;
	private String sysPassword;
	//private String newPassword;
	private String firstName;
	private String lastName;
	private String legalName;
	private String audioPath;
	private boolean customFlag;
		
	
	public boolean isCustomFlag() {
		return customFlag;
	}
	public void setCustomFlag(boolean customFlag) {
		this.customFlag = customFlag;
	}
	public String getAudioPath() {
		return audioPath;
	}
	public void setAudioPath(String audioPath) {
		this.audioPath = audioPath;
	}
	public Long getEmpID() {
		return empID;
	}
	public void setEmpID(Long empID) {
		this.empID = empID;
	}
	public String getSysPassword() {
		return sysPassword;
	}
	public void setSysPassword(String sysPassword) {
		this.sysPassword = sysPassword;
	}
	/*
	 * public String getNewPassword() { return newPassword; } public void
	 * setNewPassword(String newPassword) { this.newPassword = newPassword; }
	 */
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getLegalName() {
		return legalName;
	}
	public void setLegalName(String legalName) {
		this.legalName = legalName;
	}
	
	
	
}
