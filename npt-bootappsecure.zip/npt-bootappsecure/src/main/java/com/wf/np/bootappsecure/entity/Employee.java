package com.wf.np.bootappsecure.entity;

import java.sql.Blob;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

@Entity
public class Employee {
	
	@Id  // primary key
	@GeneratedValue(strategy = GenerationType.IDENTITY) // unique AI value 
	private Long empID;
	
	private String sysPassword;
	private String firstName;
	private String lastName;
	private String legalName;
	
	//private Blob nameAudio;
	
	private String audioPath;
	private boolean customFlag;
	
	public boolean isCustomFlag() {
		return customFlag;
	}
	public void setCustomFlag(boolean customFlag) {
		this.customFlag = customFlag;
	}
	public Long getEmpID() {
		return empID;
	}
	public void setEmpID(Long empID) {
		this.empID = empID;
	}
	public String getSysPassword() {
		return sysPassword;
	}
	public void setSysPassword(String sysPassword) {
		/*String temp=UUID.randomUUID().toString();
		sysPassword=temp.replace("-", "");*/
		this.sysPassword = sysPassword;
	}
	
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getLegalName() {
		return legalName;
	}
	public void setLegalName(String legalName) {
		this.legalName = legalName;
	}

	private String newPassword;

	public String getAudioPath() {
		return audioPath;
	}
	public void setAudioPath(String audioPath) {
		this.audioPath = audioPath;
	}

	
	//commenting
	/*
	 * //KycId as foreign key
	 * 
	 * @OneToOne(cascade=CascadeType.MERGE) private Kyc kyc;
	 * 
	 * //Accounts table mapping //@OneToMany(mappedBy="customer")
	 * 
	 * @OneToMany(mappedBy="employee") private List<Accounts> accounts;
	 * 
	 * public String getNewPassword() { return newPassword; } public void
	 * setNewPassword(String newPassword) { this.newPassword = newPassword; }
	 * 
	 * public Kyc getKyc() { return kyc; } public void setKyc(Kyc kyc) { this.kyc =
	 * kyc; } public List<Accounts> getAccounts() { return accounts; } public void
	 * setAccounts(List<Accounts> accounts) { this.accounts = accounts; }
	 */
	
}
