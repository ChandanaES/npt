package com.wf.np.bootappsecure.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.wf.np.bootappsecure.entity.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Long>{

}
