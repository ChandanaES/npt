package com.wf.np.bootappsecure.dto;


import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;

import com.google.cloud.texttospeech.v1beta1.AudioConfig;
import com.google.cloud.texttospeech.v1beta1.AudioEncoding;
import com.google.cloud.texttospeech.v1beta1.SsmlVoiceGender;
import com.google.cloud.texttospeech.v1beta1.SynthesisInput;
import com.google.cloud.texttospeech.v1beta1.SynthesizeSpeechResponse;
import com.google.cloud.texttospeech.v1beta1.TextToSpeechClient;
import com.google.cloud.texttospeech.v1beta1.VoiceSelectionParams;
import com.google.protobuf.ByteString;

import javazoom.jl.player.Player;


public class TextToSpeech {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub

		String textToSpeak = "Hello World! How are you doing today? This is Google Cloud Text-to-Speech Demo!";
        //String outputAudioFilePath = "C:/Chandana/output.mp3";
 
		// Instantiates a client
        try (TextToSpeechClient textToSpeechClient = TextToSpeechClient.create()) {
             // Set the text input to be synthesized
            SynthesisInput input = SynthesisInput.newBuilder().setText(textToSpeak).build();
 
            // Build the voice request; languageCode = "en_us"
            VoiceSelectionParams voice = VoiceSelectionParams.newBuilder().setLanguageCode("en-US")
                    .setSsmlGender(SsmlVoiceGender.FEMALE)
                    .build();
 
            // Select the type of audio file you want returned
            AudioConfig audioConfig = AudioConfig.newBuilder().setAudioEncoding(AudioEncoding.MP3) // MP3 audio.
                    .build();
 
            // Perform the text-to-speech request
            SynthesizeSpeechResponse response = textToSpeechClient.synthesizeSpeech(input, voice, audioConfig);
 
            // Get the audio contents from the response
            ByteString audioContents = response.getAudioContent();
            
            BufferedInputStream inputStream = new BufferedInputStream(new ByteArrayInputStream(audioContents.toByteArray()));
            Player player = new Player(inputStream); //player from jplayer
            player.play();
            
            
		  // Write the response to the output file. 
			/*
			 * try (OutputStream out = new FileOutputStream(outputAudioFilePath)) {
			 * out.write(audioContents.toByteArray());
			 * System.out.println("Audio content written to file \"output.mp3\""); }
			 */
			 
        }
    }
}


