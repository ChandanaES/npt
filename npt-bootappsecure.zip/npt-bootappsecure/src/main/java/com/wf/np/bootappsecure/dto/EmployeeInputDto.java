package com.wf.np.bootappsecure.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;


public class EmployeeInputDto {

	@NotNull(message="Employee ID is required")
	private Long empID;
	
	
	@NotBlank(message="Password is required")
	@Pattern(regexp="[A-Za-z0-9_]*$", message="Password allows alphanumeric characters only")
	private String password;
	
	private String userType;
		
	public Long getEmpID() {
		return empID;
	}
	public void setEmpID(Long empID) {
		this.empID = empID;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getUserType() {
		return userType;
	}
	public void setUserType(String userType) {
		this.userType = userType;
	}
	
}
